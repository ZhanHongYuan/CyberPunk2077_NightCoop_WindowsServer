$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$exe = Join-Path $root 'nightcoop_hub.exe'
$configPath = Join-Path $root 'config.json'
$keyPath = Join-Path $root 'data\hub-sign.key'
$logDir = Join-Path $root 'logs'

try {
    if (!(Test-Path -LiteralPath $exe)) { throw '找不到 nightcoop_hub.exe，请确认文件没有被杀毒软件隔离。' }
    if (!(Test-Path -LiteralPath $configPath)) { throw '找不到 config.json。' }
    $cfg = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $port = [int]$cfg.Port
    $shards = [int]$cfg.Shards
    $maxClients = [int]$cfg.MaxClients
    $hubName = [string]$cfg.HubName
    $region = [string]$cfg.Region
    if ($port -lt 1 -or $port -gt 65535) { throw 'Port 必须在 1 到 65535 之间。' }
    if ($shards -lt 1 -or $shards -gt 64) { throw 'Shards 必须在 1 到 64 之间。' }
    if ($maxClients -lt 1 -or $maxClients -gt 4095) { throw 'MaxClients 必须在 1 到 4095 之间。' }
    if ([string]::IsNullOrWhiteSpace($hubName)) { throw 'HubName 不能为空。' }
    if ([string]::IsNullOrWhiteSpace($region)) { throw 'Region 不能为空。' }
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $keyPath), $logDir | Out-Null

    Write-Host '========================================' -ForegroundColor Cyan
    Write-Host '          NightCoop Hub 启动器' -ForegroundColor Cyan
    Write-Host '========================================' -ForegroundColor Cyan
    Write-Host "服务器名称：$hubName"
    Write-Host "入口端口：UDP $port"
    Write-Host "线程数量：$shards"
    Write-Host "最大客户端：$maxClients"
    Write-Host '首次启动会自动生成本机专属密钥；以后启动会继续使用同一密钥。'
    Write-Host '请勿删除或分享 data\hub-sign.key。' -ForegroundColor Yellow
    Write-Host ''
    Write-Host '服务器日志如下（按 Ctrl+C 可停止服务器）：' -ForegroundColor Green
    Write-Host ''

    & $exe $port --shards $shards --max-clients $maxClients --sign-key-auto $keyPath --hub-name $hubName --region $region --log-dir $logDir
    $code = $LASTEXITCODE
    Write-Host ''
    Write-Host "服务器进程已退出，退出代码：$code" -ForegroundColor Yellow
    Write-Host "日志文件：$logDir\nightcoop.log"
} catch {
    Write-Host "启动失败：$($_.Exception.Message)" -ForegroundColor Red
}
