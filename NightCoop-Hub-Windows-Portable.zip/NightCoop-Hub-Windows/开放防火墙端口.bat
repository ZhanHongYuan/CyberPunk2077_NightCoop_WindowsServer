@echo off
chcp 65001 >nul
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo 正在请求管理员权限……
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
netsh advfirewall firewall delete rule name="NightCoop Hub UDP 47800" >nul 2>&1
netsh advfirewall firewall add rule name="NightCoop Hub UDP 47800" dir=in action=allow protocol=UDP localport=47800
if errorlevel 1 (
  echo 添加防火墙规则失败。
) else (
  echo 已允许 UDP 47800 入站。
  echo 如果你修改了 config.json 中的 Port，请同步修改此规则。
)
echo.
pause
