@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "data\hub-sign.key" (
  echo 尚未生成密钥。请先成功启动一次服务器。
  pause
  exit /b 1
)
if not exist "key-backup" mkdir "key-backup"
for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd-HHmmss"') do set STAMP=%%i
copy /y "data\hub-sign.key" "key-backup\hub-sign-%STAMP%.key" >nul
if errorlevel 1 (
  echo 备份失败。
) else (
  echo 密钥备份完成：key-backup\hub-sign-%STAMP%.key
  echo 警告：备份文件与原密钥同样敏感，请勿上传或发送给其他人。
)
pause
